from django.contrib import admin

# Register your models here.
from .models import ControlUser
admin.site.register(ControlUser)