from django.db import models

# Create your models here.
class ControlUser(models.Model):
  nama_faucet = models.CharField(max_length=1000)
  warna_faucet = models.CharField(max_length=1000)
  min_wd = models.CharField(max_length=1000)
  status_recaptcha = models.CharField(max_length=1000)
  min_energi = models.CharField(max_length=1000)
  reward_energi_shortlink = models.CharField(max_length=1000)
  reward_shortlink = models.CharField(max_length=1000)
  lama_auto_faucet = models.CharField(max_length=1000)
  reward_auto_faucet = models.CharField(max_length=1000)
  total_wd = models.CharField(max_length=1000)
  penarikan = models.CharField(max_length=1000)
  logo = models.CharField(max_length=1000)
  jenis_faucet = models.CharField(max_length=1000)
  url = models.CharField(max_length=1000)
  limit_faucet = models.CharField(max_length=1000)
  reward_wd = models.CharField(max_length=1000)
  api_key = models.CharField(max_length=1000)
  reward_claim = models.CharField(max_length=1000)
  lama_claim = models.CharField(max_length=1000)
  
  def __str__(self):
    return "{}".format(self.nama_faucet)