from django.shortcuts import render,redirect
from ControlUser import models as sett
from .models import shortlink as short
import json, requests
# Create your views here.
def cek():
  short1=short.objects.all()
  a=[]
  for i in short1:
    a.append(i.name)
  return a
def admin_seting_shortlink(request):
  if request.headers['User-Agent']=='':
    return render(request,'404.html')
  if request.user.is_superuser==True:
    set1 = sett.ControlUser
    seting = set1.objects.get(id="1")
    balance=json.loads(requests.post('https://faucetpay.io/api/v1/getbalance',data={"api_key":{seting.api_key},"currency":seting.jenis_faucet}).text)
    short1=short.objects.all()
    if 'short2url' in cek():
      api=short.objects.get(name="short2url")
      short2url=api.api
    else:
      short2url="None"
    if 'pvidly' in cek():
      api=short.objects.get(name="pvidly")
      pvidly=api.api
    else:
      pvidly="None"
    if 'earnow' in cek():
      api=short.objects.get(name="earnow")
      earnow=api.api
    else:
      earnow="None"
    if 'link2' in cek():
      api=short.objects.get(name="link2")
      link2=api.api
    else:
      link2="None"
    if 'shortyearn' in cek():
      api=short.objects.get(name="shortyearn")
      shortyearn=api.api
    else:
      shortyearn="None"
    if 'upshrink' in cek():
      api=short.objects.get(name="upshrink")
      upshrink=api.api
    else:
      upshrink="None"
    if 'adshorti' in cek():
      api=short.objects.get(name="adshorti")
      adshorti=api.api
    else:
      adshorti="None"
    if 'egfly' in cek():
      api=short.objects.get(name="egfly")
      egfly=api.api
    else:
      egfly="None"
    if 'adlink' in cek():
      api=short.objects.get(name="adlink")
      adlink=api.api
    else:
      adlink="None"
    if 'cbshort' in cek():
      api=short.objects.get(name="cbshort")
      cbshort=api.api
    else:
      cbshort="None"
    if 'link1s' in cek():
      api=short.objects.get(name="link1s")
      link1s=api.api
    else:
      link1s="None"
    if 'megaurl' in cek():
      api=short.objects.get(name="megaurl")
      megaurl=api.api
    else:
      megaurl="None"
    if 'riadshot' in cek():
      api=short.objects.get(name="riadshot")
      riadshot=api.api
    else:
      riadshot="None"
    if 'linkszia' in cek():
      api=short.objects.get(name="linkszia")
      linkszia=api.api
    else:
      linkszia="None"
    if 'hrshort' in cek():
      api=short.objects.get(name="hrshort")
      hrshort=api.api
    else:
      hrshort="None"
    if 'sh2rt' in cek():
      api=short.objects.get(name="sh2rt")
      sh2rt=api.api
    else:
      sh2rt="None"
    if 'zshort' in cek():
      api=short.objects.get(name="zshort")
      zshort=api.api
    else:
      zshort="None"
    if 'shrinkearn' in cek():
      api=short.objects.get(name="shrinkearn")
      shrinkearn=api.api
    else:
      shrinkearn="None"
    if 'birdurls' in cek():
      api=short.objects.get(name="birdurls")
      birdurls=api.api
    else:
      birdurls="None"
    if 'ez4short' in cek():
      api=short.objects.get(name="ez4short")
      ez4short=api.api
    else:
      ez4short="None"
    if 'clk' in cek():
      api=short.objects.get(name="clk")
      clk=api.api
    else:
      clk="None"
    if balance['status'] == 200:
        context={
          "balance":balance['balance_bitcoin'],
          "seting":seting,
          "short2url":short2url,
          "pvidly":pvidly,#✓
          "earnow":earnow,#✓
          "link2":link2,#✓
          "shortyearn":shortyearn,#✓
          "upshrink":upshrink,#✓
          "adshorti":adshorti,#✓
          "egfly":egfly,#✓
          "adlink":adlink,#✓
          "cbshort":cbshort,#✓
          "link1s":link1s,#✓
          "megaurl":megaurl,#✓
          "riadshot":riadshot,#✓
          "linkszia":linkszia,#✓
          "hrshort":hrshort,#✓
          "sh2rt":sh2rt,#
          "zshort":zshort,#✓
          "shrinkearn":shrinkearn,#✓
          "birdurls":birdurls,#✓
          "ez4short":ez4short,
          "clk":clk,#✓
          "status":"nothing",
          "sukses":"nothing",
          }
    if request.method=="POST":
      if 'short' in request.POST:
        seting.reward_shortlink = request.POST['short']
        seting.save()
      if 'energy' in request.POST:
        seting.reward_energi_shortlink = request.POST['energy']
        seting.save()
      if 'Short2' in request.POST:
        if 'Short2_up' in request.POST:
          if 'short2url' in cek():
            status=True
            short2=short.objects.get(name='short2url')
            Short2.api=request.POST['Short2_up']
            Short2.save()
          else:
            status=False
        else:
          if 'short2url' in cek():
            status=False
          else:
            api=request.POST['Short2']
            short1=short(url='https://short2url.in',api=api,name='short2url')
            short1.save()
            status=True

      if 'pvidly' in request.POST:
        if 'pvidly_up' in request.POST:
          if 'pvidly' in cek():
            status=True
            short2=short.objects.get(name='pvidly')
            Short2.api=request.POST['pvidly_up']
            Short2.save()
          else:
            status=False
        else:
          if 'pvidly' in cek():
            status=False
          else:
            api=request.POST['pvidly']
            short1=short(url='https://pvidly.in',api=api,name='pvidly')
            short1.save()
            status=True

      if 'earnow' in request.POST:
        if 'earnow_up' in request.POST:
          if 'earnow' in cek():
            status=True
            short2=short.objects.get(name='earnow')
            Short2.api=request.POST['earnow_up']
            Short2.save()
          else:
            status=False
        else:
          if 'earnow' in cek():
            status=False
          else:
            api=request.POST['earnow']
            short1=short(url='https://earnow.online',api=api,name='earnow')
            short1.save()
            status=True
            
      if 'link2' in request.POST:
        if 'link2_up' in request.POST:
          if 'link2' in cek():
            status=True
            short2=short.objects.get(name='link2')
            Short2.api=request.POST['link2_up']
            Short2.save()
          else:
            status=False
        else:
          if 'link2' in cek():
            status=False
          else:
            api=request.POST['link2']
            short1=short(url='https://link2end.com',api=api,name='link2')
            short1.save()
            status=True

      if 'shortyearn' in request.POST:
        if 'shortyearn_up' in request.POST:
          if 'shortyearn' in cek():
            status=True
            short2=short.objects.get(name='shortyearn')
            Short2.api=request.POST['shortyearn_up']
            Short2.save()
          else:
            status=False
        else:
          if 'shortyearn' in cek():
            status=False
          else:
            api=request.POST['shortyearn']
            short1=short(url='https://shortyearn.com',api=api,name='shortyearn')
            short1.save()
            status=True
            
      if 'upshrink' in request.POST:
        if 'upshrink_up' in request.POST:
          if 'upshrink' in cek():
            status=True
            short2=short.objects.get(name='upshrink')
            Short2.api=request.POST['upshrink_up']
            Short2.save()
          else:
            status=False
        else:
          if 'upshrink' in cek():
            status=False
          else:
            api=request.POST['upshrink']
            short1=short(url='https://upshrink.com',api=api,name='upshrink')
            short1.save()
            status=True

      if 'adshorti' in request.POST:
        if 'adshorti_up' in request.POST:
          if 'adshorti' in cek():
            status=True
            short2=short.objects.get(name='adshorti')
            Short2.api=request.POST['adshorti_up']
            Short2.save()
          else:
            status=False
        else:
          if 'adshorti' in cek():
            status=False
          else:
            api=request.POST['adshorti']
            short1=short(url='https://adshorti.co',api=api,name='adshorti')
            short1.save()
            status=True
            
      if 'egfly' in request.POST:
        if 'egfly_up' in request.POST:
          if 'egfly' in cek():
            status=True
            short2=short.objects.get(name='egfly')
            Short2.api=request.POST['egfly_up']
            Short2.save()
          else:
            status=False
        else:
          if 'egfly' in cek():
            status=False
          else:
            api=request.POST['egfly']
            short1=short(url='https://egfly.xyz',api=api,name='egfly')
            short1.save()
            status=True

      if 'adlink' in request.POST:
        if 'adlink_up' in request.POST:
          if 'adlink' in cek():
            status=True
            short2=short.objects.get(name='adlink')
            Short2.api=request.POST['adlink_up']
            Short2.save()
          else:
            status=False
        else:
          if 'adlink' in cek():
            status=False
          else:
            api=request.POST['adlink']
            short1=short(url='https://adlink.click',api=api,name='adlink')
            short1.save()
            status=True

      if 'cbshort' in request.POST:
        if 'cbshort_up' in request.POST:
          if 'cbshort' in cek():
            status=True
            short2=short.objects.get(name='cbshort')
            Short2.api=request.POST['cbshort_up']
            Short2.save()
          else:
            status=False
        else:
          if 'cbshort' in cek():
            status=False
          else:
            api=request.POST['cbshort']
            short1=short(url='https://cbshort.com',api=api,name='cbshort')
            short1.save()
            status=True

      if 'link1s' in request.POST:
        if 'link1s_up' in request.POST:
          if 'link1s' in cek():
            status=True
            short2=short.objects.get(name='link1s')
            Short2.api=request.POST['link1s_up']
            Short2.save()
          else:
            status=False
        else:
          if 'link1s' in cek():
            status=False
          else:
            api=request.POST['link1s']
            short1=short(url='https://link1s.com',api=api,name='link1s')
            short1.save()
            status=True

      if 'megaurl' in request.POST:
        if 'megaurl_up' in request.POST:
          if 'megaurl' in cek():
            status=True
            short2=short.objects.get(name='megaurl')
            Short2.api=request.POST['megaurl_up']
            Short2.save()
          else:
            status=False
        else:
          if 'megaurl' in cek():
            status=False
          else:
            api=request.POST['megaurl']
            short1=short(url='https://megaurl.io',api=api,name='megaurl')
            short1.save()
            status=True
            
      if 'linkszia' in request.POST:
        if 'linkszia_up' in request.POST:
          if 'linkszia' in cek():
            status=True
            short2=short.objects.get(name='linkszia')
            Short2.api=request.POST['linkszia_up']
            Short2.save()
          else:
            status=False
        else:
          if 'linkszia' in cek():
            status=False
          else:
            api=request.POST['linkszia']
            short1=short(url='https://linkszia.co',api=api,name='linkszia')
            short1.save()
            status=True

      if 'riadshot' in request.POST:
        if 'riadshot_up' in request.POST:
          if 'riadshot' in cek():
            status=True
            short2=short.objects.get(name='riadshot')
            Short2.api=request.POST['riadshot_up']
            Short2.save()
          else:
            status=False
        else:
          if 'riadshot' in cek():
            status=False
          else:
            api=request.POST['riadshot']
            short1=short(url='https://riadshot.in',api=api,name='riadshot')
            short1.save()
            status=True
            
      if 'hrshort' in request.POST:
        if 'hrshort_up' in request.POST:
          if 'hrshort' in cek():
            status=True
            short2=short.objects.get(name='hrshort')
            Short2.api=request.POST['hrshort_up']
            Short2.save()
          else:
            status=False
        else:
          if 'riadshot' in cek():
            status=False
          else:
            api=request.POST['riadshot']
            short1=short(url='https://hrshort.com',api=api,name='riadshot')
            short1.save()
            status=True

      if 'sh2rt' in request.POST:
        if 'sh2rt_up' in request.POST:
          if 'sh2rt' in cek():
            status=True
            short2=short.objects.get(name='sh2rt')
            Short2.api=request.POST['sh2rt_up']
            Short2.save()
          else:
            status=False
        else:
          if 'sh2rt' in cek():
            status=False
          else:
            api=request.POST['sh2rt']
            short1=short(url='https://sh2rt.com',api=api,name='sh2rt')
            short1.save()
            status=True

      if 'zshort' in request.POST:
        if 'zshort_up' in request.POST:
          if 'zshort' in cek():
            status=True
            short2=short.objects.get(name='zshort')
            Short2.api=request.POST['zshort_up']
            Short2.save()
          else:
            status=False
        else:
          if 'zshort' in cek():
            status=False
          else:
            api=request.POST['zshort']
            short1=short(url='https://zshort.io',api=api,name='zshort')
            short1.save()
            status=True

      if 'shrinkearn' in request.POST:
        if 'shrinkearn_up' in request.POST:
          if 'shrinkearn' in cek():
            status=True
            short2=short.objects.get(name='shrinkearn')
            Short2.api=request.POST['shrinkearn_up']
            Short2.save()
          else:
            status=False
        else:
          if 'shrinkearn' in cek():
            status=False
          else:
            api=request.POST['shrinkearn']
            short1=short(url='https://shrinkearn.com',api=api,name='shrinkearn')
            short1.save()
            status=True

      if 'birdurls' in request.POST:
        if 'birdurls_up' in request.POST:
          if 'birdurls' in cek():
            status=True
            short2=short.objects.get(name='birdurls')
            Short2.api=request.POST['birdurls_up']
            Short2.save()
          else:
            status=False
        else:
          if 'birdurls' in cek():
            status=False
          else:
            api=request.POST['birdurls']
            short1=short(url='https://birdurls.com',api=api,name='birdurls')
            short1.save()
            status=True

      if 'ez4short' in request.POST:
        if 'ez4short_up' in request.POST:
          if 'ez4short' in cek():
            status=True
            short2=short.objects.get(name='ez4short')
            Short2.api=request.POST['ez4short_up']
            Short2.save()
          else:
            status=False
        else:
          if 'ez4short' in cek():
            status=False
          else:
            api=request.POST['ez4short']
            short1=short(url='https://ez4short.com',api=api,name='ez4short')
            short1.save()
            status=True
            
      if 'clk' in request.POST:
        if 'clk_up' in request.POST:
          if 'clk' in cek():
            status=True
            short2=short.objects.get(name='clk')
            Short2.api=request.POST['clk_up']
            Short2.save()
          else:
            status=False
        else:
          if 'clk' in cek():
            status=False
          else:
            api=request.POST['clk']
            short1=short(url='https://clk.sh',api=api,name='clk')
            short1.save()
            status=True
      return redirect('/admin/seting_shortlink')
    return render(request,'admin_shortlink.html',context)
  else:
    return redirect('/admin/login')