from django.db import models

# Create your models here.
class shortlink(models.Model):
  name = models.CharField(max_length=1000)
  url = models.CharField(max_length=1000)
  api = models.CharField(max_length=1000)
  def __str__(self):
    return "{}".format(self.url)