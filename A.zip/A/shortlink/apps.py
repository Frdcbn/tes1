from django.apps import AppConfig


class ShortlinkConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shortlink'
