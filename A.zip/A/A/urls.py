from django.contrib import admin
from django.urls import path,include,re_path
from django.conf.urls import handler404, handler500
from . import views
from user import views as user
from shortlink import views as s
urlpatterns = [
    path('admin/', user.admin),
    path('admin/login', user.admin_login),
    path('admin/user_setting', user.admin_user_setting),
    path('admin/user_list', user.admin_user_list),
    path('admin/faucet', user.admin_faucet),
    path('admin/auto', user.admin_auto),
    path('admin/seting_shortlink', s.admin_seting_shortlink),
    path('', views.index),
    path('login/', user.login),
    path('register/', user.register),
    path('dashboard/', views.dashboard),
    path('auto/', views.auto),
    path('faucet/', views.faucet),
    path('logout/', user.logout1),
    path('admin_django/', admin.site.urls),
    path('shortlink/', views.shortlink),
    path('verify/<str:id>/<str:token>', views.verify),
    path('referral/<str:id>', views.referral),
    path('<str:nama>/', views.ad),
]

handler404='A.views.error_404'
handler403='A.views.csrf_failure'
handler500='A.views.kentod'
