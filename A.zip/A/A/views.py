from django.shortcuts import render,redirect
from user import models
from user import forms
from ControlUser import models as sett
from shortlink import models as short
import requests
import datetime
import secrets
import random
import string
import json
import time
def index(request):
  if request.headers['User-Agent']=='':
    return render(request,'404.html')
  context = {
    "user":"MR.BADUT",
    "credit":"MR.BADUT",
    }
  if str(request.user) == 'AnonymousUser':
    set1 = sett.ControlUser
    seting = set1.objects.get(id="1")
    info = models.User
    jumlah=len(info.objects.all())
    context={
    "seting":seting,
    "jumlah":jumlah,
    "status_login":False,
    "nav":[
        ["active","/","Home Page"],
        ["","/login","Login"],
        ["","/register","Register"],
        ["","/about","About"],
        ]
        }
  else:
      set1 = sett.ControlUser
      info = models.User
      seting = set1.objects.get(id="1")
      user=info.objects.get(username=str(request.user))
      jumlah=len(info.objects.all())
      if "active" not in user.status:
        return redirect('/logout/')
      context ={
      "seting":seting,
      "jumlah":jumlah,
      "status_login":True,
      "nav":[
      ["active","/","Home Page"],
      ["","/dashboard","Dashboard"],
      ["","/about","About"],
      ["","/logout","Logout"],
      ]
      }
  return render(request,'index.html',context)
def dashboard(request):
  if request.headers['User-Agent']=='':
    return render(request,'404.html')
  if str(request.user) == 'AnonymousUser':
    return redirect('/')
  else:
    set1 = sett.ControlUser
    info = models.User
    seting = set1.objects.get(id="1")
    user=info.objects.get(username=str(request.user))
    if "active" not in user.status:
      return redirect('/logout/')
    if request.method == 'POST':
      jumlah=request.POST['amount']
      wallet=request.POST['wallet']
      user=info.objects.get(username=str(request.user))
      if int(jumlah) >= int(seting.min_wd):
        if int(user.balance) >=  int(seting.min_wd):
          if int(jumlah) <= int(user.balance):
            jumlahwd = eval(f"{jumlah}*{seting.reward_wd}")
            data= {"api_key":{seting.api_key},"amount":int(jumlahwd),"to":wallet,"currency":{seting.jenis_faucet}}
            a=json.loads(requests.post('https://faucetpay.io/api/v1/send',data=data).text)
            if a["status"] == 200:
              sukses = True
              bal=eval(f"{str(user.balance)}-{str(jumlah)}")
              member = info.objects.get(id=user.id)
              member.total_wd=eval(f"{str(user.total_wd)}+{str(jumlah)}")
              seting.total_wd=eval(f"{str(jumlah)}+{str(seting.total_wd)}")
              seting.penarikan=eval(f"1+{str(seting.penarikan)}")
              member.balance = bal
              if user.wallet == None:
                member.wallet = wallet
              member.save()
              seting.save()
            else:
              sukses = False
            user=info.objects.get(username=str(request.user))
            context={
            "username":user,
            "salah":False,
            "sukses":sukses,
            "bct":seting,
            "nav":[
            ["active","/dashboard","Dashboard"],
            ["","/faucet","Faucet"],
            ["","/shortlink","Shortlink"],
            ["","/logout","Logout"],
            ]
            }
            return render(request,'dashboard.html',context)
          else:
            context={
            "username":user,
            "salah":True,
            "bct":seting,
            "nav":[
            ["active","/dashboard","Dashboard"],
            ["","/faucet","Faucet"],
            ["","/shortlink","Shortlink"],
            ["","/logout","Logout"],
            ]
            }
            return render(request,'dashboard.html',context)
        #batas
        else:
          context={
          "username":user,
          "bct":seting,
          "salah":True,
          "nav":[
          ["active","/dashboard","Dashboard"],
          ["","/faucet","Faucet"],
          ["","/shortlink","Shortlink"],
          ["","/logout","Logout"],
          ]
          }
          return render(request,'dashboard.html',context)
      else:
        context={
        "username":user,
        "bct":seting,
        "salah":"kurang",
        "nav":[
        ["active","/dashboard","Dashboard"],
        ["","/faucet","Faucet"],
        ["","/shortlink","Shortlink"],
        ["","/logout","Logout"],
        ]
        }
        return render(request,'dashboard.html',context)
    else:
      user=info.objects.get(username=str(request.user))
      context={
      "username":user,
      "salah":"",
      "bct":seting,
      "nav":[
      ["active","/dashboard","Dashboard"],
      ["","/faucet","Faucet"],
      ["","/shortlink","Shortlink"],
      ["","/logout","Logout"],
      ]
      }
      return render(request,'dashboard.html',context)
def faucet(request):
  if request.headers['User-Agent']=='':
    return render(request,'404.html')
  if str(request.user) == 'AnonymousUser':
    return redirect('/')
  else:
    set1 = sett.ControlUser
    info = models.User
    seting = set1.objects.get(id="1")
    user=info.objects.get(username=str(request.user))
    if "active" not in user.status:
      return redirect('/logout/')
    tahun=int(datetime.datetime.now().strftime("%Y"))
    tanggal=int(datetime.datetime.now().strftime("%d"))
    bulan=int(datetime.datetime.now().strftime("%m"))
    jam=int(datetime.datetime.now().strftime("%H"))
    menit=int(datetime.datetime.now().strftime("%M"))
    detik=int(datetime.datetime.now().strftime("%S"))
    date_and_time = datetime.datetime(tahun, bulan, tanggal, jam, menit, detik)
    if str(user.waktu_claim) <= str(date_and_time):
      token=secrets.token_hex(16)
      form = forms.cp(request.POST)
      user=info.objects.get(username=str(request.user))
      if user.limit=="1":
        tahun=int(datetime.datetime.now().strftime("%Y"))
        tanggal=int(datetime.datetime.now().strftime("%d"))
        bulan=int(datetime.datetime.now().strftime("%m"))
        tanggal_reset = datetime.datetime(tahun, bulan, tanggal)
        time_change = datetime.timedelta(days=1)
        reset = tanggal_reset + time_change
        member = info.objects.get(id=user.id)
        member.reset=reset
        member.save()
      tahun=int(datetime.datetime.now().strftime("%Y"))
      tanggal=int(datetime.datetime.now().strftime("%d"))
      bulan=int(datetime.datetime.now().strftime("%m"))
      skrng = datetime.datetime(tahun, bulan, tanggal)
      if str(user.reset) <= str(skrng):
          member = info.objects.get(id=user.id)
          member.limit=seting.limit_faucet
          member.reset ="None"
          member.save()
      context={
      "form":form,
      "username":user,
      "token":token,
      "seting":seting,
      "salah":"nothing",
      "limit":user,
      "nav":[
      ["","/dashboard","Dashboard"],
      ["active","/faucet","Faucet"],
      ["","/shortlink","Shortlink"],
      ["","/logout","Logout"],
      ]
      }
      if request.method == 'POST':
        if form.is_valid():
          if user.limit=="0":
            context["salah"]="limit"
            return render(request,'faucet.html',context)
          if str(user.waktu_claim) <= str(date_and_time):
            bal=eval(str(f"{user.balance}+{seting.reward_claim}"))
            member = info.objects.get(id=user.id)
            member.balance = bal
            tahun=int(datetime.datetime.now().strftime("%Y"))
            tanggal=int(datetime.datetime.now().strftime("%d"))
            bulan=int(datetime.datetime.now().strftime("%m"))
            jam=int(datetime.datetime.now().strftime("%H"))
            menit=int(datetime.datetime.now().strftime("%M"))
            detik=int(datetime.datetime.now().strftime("%S"))
            date_and_time = datetime.datetime(tahun, bulan, tanggal, jam, menit, detik)
            time_change = datetime.timedelta(minutes=int(seting.lama_claim))
            new_time = date_and_time + time_change
            member.waktu_claim = new_time
            member.limit=eval(f"{user.limit}-1")
            member.save()
            hasil=int(seting.lama_claim)*60
            context={
      "form":form,
      "username":user,
      "token":token,
      "waktu":True,
      "seting1":hasil,
      "seting":seting,
      "salah":"Sukses",
      "limit":user}
            return render(request,'faucet.html',context)
          else:
            context["salah"]="belum_waktunya"
            return render(request,'faucet.html',context)
        else:
          context["salah"]="cp_salah"
          return render(request,'faucet.html',context)
    else:
      token=secrets.token_hex(16)
      form = forms.cp(request.POST)
      hasil=int(seting.lama_claim)*60
      context={
      "form":form,
      "username":user,
      "token":token,
      "seting":seting,
      "seting1":hasil,
      "waktu":True,
      "salah":"belum_waktunya",
      "limit":user,
      }
      return render(request,'faucet.html',context)
    return render(request,'faucet.html',context)
def shortlink(request):
    if request.headers['User-Agent']=='':
      return render(request,'404.html')
    if str(request.user) == 'AnonymousUser':
      return redirect('/')
    else:
        set1 = sett.ControlUser
        info = models.User
        shortl=short.shortlink
        short1=shortl.objects.all()
        seting = set1.objects.get(id="1")
        user=info.objects.get(username=str(request.user))
        if "active" not in user.status:
          return redirect('/logout/')
        tahun=int(datetime.datetime.now().strftime("%Y"))
        tanggal=int(datetime.datetime.now().strftime("%d"))
        bulan=int(datetime.datetime.now().strftime("%m"))
        date_and_time = datetime.datetime(tahun, bulan, tanggal)
        
        def cek(short1):
          true=[]
          for name in short1:
            if "short2url" in name.name:
              if user.short2url_waktu<= str(date_and_time):
                true.append(name.name)
            if "pvidly" in name.name:
              if user.pvidly_waktu<= str(date_and_time):
                true.append(name.name)
            if "earnow" in name.name:
              if user.earnow_waktu<= str(date_and_time):
                true.append(name.name)
            if "link2" in name.name:
              if user.link2_waktu<= str(date_and_time):
                true.append(name.name)
            if "adshorti" in name.name:
              if user.adshorti_waktu<= str(date_and_time):
                true.append(name.name)
            if "shortyearn" in name.name:
              if user.shortyearn_waktu<= str(date_and_time):
                true.append(name.name)
            if "upshrink" in name.name:
              if user.upshrink_waktu<= str(date_and_time):
                true.append(name.name)
            if "egfly" in name.name:
              if user.egfly_waktu<= str(date_and_time):
                true.append(name.name)
            if "adlink" in name.name:
              if user.adlink_waktu<= str(date_and_time):
                true.append(name.name)
            if "cbshort" in name.name:
              if user.cbshort_waktu<= str(date_and_time):
                true.append(name.name)
            if "link1s" in name.name:
              if user.link1s_waktu<= str(date_and_time):
                true.append(name.name)
            if "megaurl" in name.name:
              if user.megaurl_waktu<= str(date_and_time):
                true.append(name.name)
            if "riadshot" in name.name:
              if user.riadshot_waktu<= str(date_and_time):
                true.append(name.name)
            if "linkszia" in name.name:
              if user.linkszia_waktu<= str(date_and_time):
                true.append(name.name)
            if "hrshort" in name.name:
              if user.hrshort_waktu<= str(date_and_time):
                true.append(name.name)
            if "zshort" in name.name:
              if user.zshort_waktu<= str(date_and_time):
                true.append(name.name)
            if "shrinkearn" in name.name:
              if user.shrinkearn_waktu<= str(date_and_time):
                true.append(name.name)
            if "birdurls" in name.name:
              if user.birdurls_waktu<= str(date_and_time):
                true.append(name.name)
            if "ez4short" in name.name:
              if user.ez4short_waktu<= str(date_and_time):
                true.append(name.name)
            if "clk" in name.name:
              if user.clk_waktu<= str(date_and_time):
                true.append(name.name)
          return true
        Total_energi=len(cek(short1))*int(seting.reward_energi_shortlink)
        Total_token=len(cek(short1))*int(seting.reward_shortlink)
        context={
        "username":user.username,
        "seting":seting,
        "waktu":date_and_time,
        "jumlah_energi":str(Total_energi),
        "jumlah_token":str(Total_token),
        "shortlink":cek(short1),
        }
        if request.method == 'POST':
          for isi in short1:
            if isi.name in request.POST:
                token=secrets.token_hex(26)
                lower = string.ascii_lowercase
                upper = string.ascii_uppercase
                all = lower+upper
                pa = "".join(random.sample(all,7))
                url=f"{seting.url}/verify/{isi.name}/{token}"
                response=requests.get(f'{isi.url}/api?api={isi.api}&url={url}&alias={pa}').text
                process=json.loads(response)
                if process['status']=='success':
                  member = info.objects.get(id=user.id)
                  if "short2url" in request.POST:
                    member.short2url=token
                    member.save()
                  if "pvidly" in request.POST:
                    member.pvidly=token
                    member.save()
                  if "earnow" in request.POST:
                    member.earnow=token
                    member.save()
                  if "link2" in request.POST:
                    member.link2=token
                    member.save()
                  if "adshorti" in request.POST:
                    member.adshorti=token
                    member.save()
                  if "shortyearn" in request.POST:
                    member.shortyearn=token
                    member.save()
                  if "upshrink" in request.POST:
                    member.upshrink=token
                    member.save()
                  if "egfly" in request.POST:
                    member.egfly=token
                    member.save()
                  if "adlink" in request.POST:
                    member.adlink=token
                    member.save()
                  if "cbshort" in request.POST:
                    member.cbshort=token
                    member.save()
                  if "link1s" in request.POST:
                    member.link1s=token
                    member.save()
                  if "megaurl" in request.POST:
                    member.megaurl=token
                    member.save()
                  if "riadshot" in request.POST:
                    member.riadshot=token
                    member.save()
                  if "linkszia" in request.POST:
                    member.linkszia=token
                    member.save()
                  if "hrshort" in request.POST:
                    member.hrshort=token
                    member.save()
                  if "zshort" in request.POST:
                    member.zshort=token
                    member.save()
                  if "shrinkearn" in request.POST:
                    member.shrinkearn=token
                    member.save()
                  if "birdurls" in request.POST:
                    member.birdurls=token
                    member.save()
                  if "ez4short" in request.POST:
                    member.ez4short=token
                    member.save()
                  if "clk" in request.POST:
                    member.clk=token
                    member.save()
                  return redirect(process['shortenedUrl'])
                else:
                  context={"gagal":True}
        return render(request,'shortlink.html',context)
def verify(request,id,token):
  if request.headers['User-Agent']=='':
    return render(request,'404.html')
  if str(request.user) == 'AnonymousUser':
    return redirect('/')
  else:
    set1 = sett.ControlUser
    info = models.User
    seting = set1.objects.get(id="1")
    user=info.objects.get(username=str(request.user))
    tahun=int(datetime.datetime.now().strftime("%Y"))
    tanggal=int(datetime.datetime.now().strftime("%d"))
    bulan=int(datetime.datetime.now().strftime("%m"))
    date_and_time = datetime.datetime(tahun, bulan, tanggal)
    time_change = datetime.timedelta(days=1)
    new_time = date_and_time + time_change
    member = info.objects.get(id=user.id)
    if id == "short2url":
      if token == member.short2url:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.short2url_waktu = new_time
        member.short2url ="None"
        member.save()
        return redirect('/dashboard')
    if id == "pvidly":
      if token == member.pvidly:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.pvidly_waktu = new_time
        member.pvidly = "None"
        member.save()
        return redirect('/dashboard')
    if id == "earnow":
      if token == member.earnow:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.earnow_waktu = new_time
        member.earnow = "None"
        member.save()
        return redirect('/dashboard')
    if id == "link2":
      if token == member.link2:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.link2_waktu = new_time
        member.link2 = "None"
        member.save()
        return redirect('/dashboard')
    if id == "adshorti":
      if token == member.adshorti:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.adshorti_waktu = new_time
        member.adshorti = "None"
        member.save()
        return redirect('/dashboard')
    if id == "shortyearn":
      if token == member.shortyearn:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.shortyearn_waktu = new_time
        member.shortyearn = "None"
        member.save()
        return redirect('/dashboard')
    if id == "upshrink":
      if token == member.upshrink:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.upshrink_waktu = new_time
        member.upshrink = "None"
        member.save()
        return redirect('/dashboard')
    if id == "egfly":
      if token == member.egfly:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.egfly_waktu = new_time
        member.egfly = "None"
        member.save()
        return redirect('/dashboard')
    if id == "adlink":
      if token == member.adlink:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.adlink_waktu = new_time
        member.adlink = "None"
        member.save()
        return redirect('/dashboard')
    if id == "cbshort":
      if token == member.cbshort:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.cbshort_waktu = new_time
        member.cbshort = "None"
        member.save()
        return redirect('/dashboard')
    if id == "link1s":
      if token == member.link1s:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.link1s_waktu = new_time
        member.link1s = "None"
        member.save()
        return redirect('/dashboard')
    if id == "megaurl":
      if token == member.megaurl:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.megaurl_waktu = new_time
        member.megaurl = "None"
        member.save()
        return redirect('/dashboard')
    if id == "riadshot":
      if token == member.riadshot:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.riadshot_waktu = new_time
        member.riadshot = "None"
        member.save()
        return redirect('/dashboard')
    if id == "linkszia":
      if token == member.linkszia:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.linkszia_waktu = new_time
        member.linkszia = "None"
        member.save()
        return redirect('/dashboard')
    if id == "hrshort":
      if token == member.hrshort:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.hrshort_waktu = new_time
        member.hrshort = "None"
        member.save()
        return redirect('/dashboard')
    if id == "zshort":
      if token == member.zshort:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.zshort_waktu = new_time
        member.zshort = "None"
        member.save()
        return redirect('/dashboard')
    if id == "shrinkearn":
      if token == member.shrinkearn:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.shrinkearn_waktu = new_time
        member.shrinkearn = "None"
        member.save()
        return redirect('/dashboard')
    if id == "birdurls":
      if token == member.birdurls:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.birdurls_waktu = new_time
        member.birdurls = "None"
        member.save()
        return redirect('/dashboard')
    if id == "ez4short":
      if token == member.ez4short:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.ez4short_waktu = new_time
        member.ez4short = "None"
        member.save()
        return redirect('/dashboard')
    if id == "clk":
      if token == member.clk:
        member.balance = eval(f"{seting.reward_shortlink}+{member.balance}")         
        member.energi = eval(f"{seting.reward_energi_shortlink}+{member.energi}")
        member.clk_waktu = new_time
        member.clk = "None"
        member.save()
        return redirect('/dashboard')
    return redirect('/dashboard/')
def error_404(request, exception,reason="Forbidden 403"):
  return render(request,'404.html',status=404)
def kentod(request, *args, **argv):
    return HttpResponse('something seems wrong',status=500)
def csrf_failure(request, reason="Forbidden 403"):
  return render(request,'403_csrf.html',status=403)
def referral(request,id):
  if request.headers['User-Agent']=='':
    return render(request,'404.html')
  request.session["refferal"] = id
  return redirect('/')
def ad(request,nama):
  if request.headers['User-Agent']=='':
    return render(request,'404.html')
  try:
    return render(request,nama)
  except:
    return render(request,"404.html",context={"None":"None"})
    pass
def auto(request):
  if request.headers['User-Agent']=='':
    return render(request,'404.html')
  if str(request.user) == 'AnonymousUser':
    return redirect('/')
  else:
    set1 = sett.ControlUser
    info = models.User
    seting = set1.objects.get(id="1")
    user=info.objects.get(username=str(request.user))
    if "active" not in user.status:
      return redirect('/logout/')
    hasil=int(seting.lama_auto_faucet)*60
    token=secrets.token_hex(16)
    if seting.min_energi == None:
      isi=True
    else:
      if int(seting.min_energi) <= int(user.energi):
        isi=True
      else:
        isi=False
    context={
      "token":token,
      "seting":seting,
      "lama":hasil,
      "status":"nothing",
      "None":isi,
    }
    if request.method == 'POST':
      if seting.min_energi == None:
        member = info.objects.get(id=user.id)
        member.balance = int(user.balance)+int(seting.reward_auto_faucet)
        member.save()
        context={
        "token":token,
        "seting":seting,
        "lama":hasil,
        "status":True,
        "None":isi,
          }
        return render(request,"auto.html",context)
      else:
        if int(seting.min_energi) <= int(user.energi):
          member = info.objects.get(id=user.id)
          member.balance = eval(user.balance+'+'+seting.reward_auto_faucet)
          hasil = eval(user.energi+'-'+seting.min_energi)
          member.energi=hasil
          member.save()
          context={
          "token":token,
          "seting":seting,
          "lama":hasil,
          "status":True,
          "None":isi,
          }
          return render(request,"auto.html",context)
        else:
          context={
          "token":token,
          "seting":seting,
          "lama":hasil,
          "status":False,
          "None":isi,
          }
          return render(request,"auto.html",context)
    return render(request,"auto.html",context)