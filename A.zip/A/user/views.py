from django.shortcuts import render , redirect
from .models import User as Info
from ControlUser import models as sett
from .forms import cp
import datetime
import json, requests
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth import login as auth_login
import requests
import socket
def cek_email(email):
  try:
    cek=User.objects.get(email=email)
  except Exception as e:
    if 'User matching query does not exist.' in str(e):
      respon = True
      return respon
    else:
      respon = False
      return respon
def cek_ip(ip):
  try:
    cek=Info.objects.get(ip=ip)
  except Exception as e:
    if 'User matching query does not exist.' in str(e):
      respon = True
      return respon
    else:
      respon = False
      return respon
def get_client_ip():
    hostname = socket.gethostname()
    IPAddr = socket.gethostbyname(hostname)
    return IPAddr
def register(request):
  set1 = sett.ControlUser
  seting = set1.objects.get(id="1")
  if str(request.user) == 'AnonymousUser':
    negara=json.loads(requests.get('http://ip-api.com/json').text)["country"]
    form = cp()
    context = {
      'form':form,
      "user":"MR.BADUT",
      "seting":seting,
      "credit":"MR.BADUT",
      "nav":[
        ["","/","Home Page"],
        ["","/login","Login"],
        ["active","/register","Register"],
        ["","/about","About"],
        ]
    }
    if request.method == 'POST':
      try:
        if request.POST['password1'] == request.POST['password2']:
          username=request.POST['Username']
          email=request.POST['email']
          password=request.POST['password1']
          if cek_email(email)==True:
           yoi = get_client_ip()
           if cek_ip(yoi)== True:
            form = cp(request.POST)
            if form.is_valid(): 
              user = User.objects.create_user(username=username, email=email, password=password)
              wak="2022-08-05 00:00:00"
              if 'refferal' in request.session:
                refi = request.session["refferal"]
                undang=Info.objects.get(id=refi)
                undang.reff = eval(f"1+{undang.reff}")
                undang.save()
              else:
                refi = '0'
              tahun=int(datetime.datetime.now().strftime("%Y"))
              tanggal=int(datetime.datetime.now().strftime("%d"))
              bulan=int(datetime.datetime.now().strftime("%m"))
              jam=int(datetime.datetime.now().strftime("%H"))
              reset = datetime.datetime(tahun, bulan, tanggal)
              #haj#
              tahun=int(datetime.datetime.now().strftime("%Y"))
              tanggal=int(datetime.datetime.now().strftime("%d"))
              bulan=int(datetime.datetime.now().strftime("%m"))
              jam=int(datetime.datetime.now().strftime("%H"))
              menit=int(datetime.datetime.now().strftime("%M"))
              detik=int(datetime.datetime.now().strftime("%S"))
              joined = datetime.datetime(tahun, bulan, tanggal, jam, menit, detik)
              info=Info(balance='0',energi='0',email=email,reff='0',status='active', username=username,total_wd='0',waktu_claim='0',reffnya=refi,reset=reset,limit=seting.limit_faucet,negara=negara,joined=joined,ip=yoi,short2url_waktu=wak,pvidly_waktu=wak,earnow_waktu=wak,link2_waktu=wak,adshorti_waktu=wak,shortyearn_waktu=wak,upshrink_waktu=wak,egfly_waktu=wak,adlink_waktu=wak,cbshort_waktu=wak,link1s_waktu=wak,megaurl_waktu=wak,riadshot_waktu=wak,linkszia_waktu=wak,hrshort_waktu=wak,zshort_waktu=wak,shrinkearn_waktu=wak,birdurls_waktu=wak,ez4short_waktu=wak,clk_waktu=wak,short2url = "None",pvidly = "None",earnow = "None",link2 = "None",adshorti = "None",shortyearn = "None",upshrink = "None",egfly = "None",adlink = "None",cbshort = "None",link1s = "None",megaurl = "None",riadshot = "None",linkszia = "None",hrshort = "None",zshort = "None",shrinkearn = "None",birdurls = "None",ez4short = "None",clk = "None",)
              info.save()
              context = {
              'form':form,
              "user":"MR.BADUT",
              "credit":"MR.BADUT",
              "salah":False,
              "nav":[
                ["","/","Home Page"],
                ["","/login","Login"],
                ["active","/register","Register"],
                ["","/about","About"],
                ]
            }
              return redirect('/dashboard/')
            else:
              context = {
              'form':form,
              "user":"MR.BADUT",
              "credit":"MR.BADUT",
              "salah":"cp",
              "nav":[
                ["","/","Home Page"],
                ["","/login","Login"],
                ["active","/register","Register"],
                ["","/about","About"],
                ]
            }
              return render(request,'register.html',context)
           else:
             context = {
              'form':form,
              "user":"MR.BADUT",
              "credit":"MR.BADUT",
              "salah":"sudahip",
              "nav":[
                ["","/","Home Page"],
                ["","/login","Login"],
                ["active","/register","Register"],
                ["","/about","About"],
                ]
            }
             return render(request,'register.html',context)
          else:
            context = {
              'form':form,
              "user":"MR.BADUT",
              "credit":"MR.BADUT",
              "salah":"sudah",
              "nav":[
                ["","/","Home Page"],
                ["","/login","Login"],
                ["active","/register","Register"],
                ["","/about","About"],
                ]
            }
            return render(request,'register.html',context)
        else:
            context = {
            'form':form,
            "user":"MR.BADUT",
            "credit":"MR.BADUT",
            "salah":True,
            "nav":[
              ["","/","Home Page"],
              ["","/login","Login"],
              ["active","/register","Register"],
              ["","/about","About"],
              ]
          }
      except Exception as e:
        print(e)
        context = {
            'form':form,
            "user":"MR.BADUT",
            "credit":"MR.BADUT",
            "salah":"sama",
            "nav":[
              ["","/","Home Page"],
              ["","/login","Login"],
              ["active","/register","Register"],
              ["","/about","About"],
              ]
          }
        return render(request,'register.html',context)
    return render(request,'register.html',context)
  else: 
    return redirect('/')
def login(request):
  set1 = sett.ControlUser
  seting = set1.objects.get(id="1")
  if str(request.user) == 'AnonymousUser':
    form = cp()
    context = {
      'form':form,
      "user":"MR.BADUT",
      "seting":seting,
      "credit":"MR.BADUT",
      "nav":[
        ["","/","Home Page"],
        ["active","/login","Login"],
        ["","/register","Register"],
        ["","/about","About"],
        ]
    }
    #print(request.session['email'])
    if request.method == 'POST':
        username=request.POST['Username']
        password=request.POST['password']
        cek = Info.objects.get(username=username)
        if "active" not in cek.status:
          context = {
            'form':form,
            "user":"MR.BADUT",
            "credit":"MR.BADUT",
            'salah':"ban",
            "nav":[
              ["","/","Home Page"],
              ["active","/login","Login"],
              ["","/register","Register"],
              ["","/about","About"],
              ]
            }
          return render(request,"login.html",context)
        else:
          user = authenticate(username=username, password=password)
          form = cp(request.POST)
          if form.is_valid():
            if user is not None:
              auth_login(request, user)
              isi=Info.objects.get(username=username)
              return redirect('/dashboard/')
            else:
              context = {
              'form':form,
              "user":"MR.BADUT",
              "credit":"MR.BADUT",
              'salah':True,
              "nav":[
                ["","/","Home Page"],
                ["active","/login","Login"],
                ["","/register","Register"],
                ["","/about","About"],
                ]
            }
              return render(request,"login.html",context)
          else:
            context = {
              'form':form,
              "user":"MR.BADUT",
              "credit":"MR.BADUT",
              'salah':"cp",
              "nav":[
                ["","/","Home Page"],
                ["active","/login","Login"],
                ["","/register","Register"],
                ["","/about","About"],
                ]
            }
    return render(request,'login.html',context)
  else:
    return redirect('/')
def logout1(request):
  if str(request.user) == 'AnonymousUser':
    return redirect('/')
  else:
      logout(request)
      return redirect('/')
#admin
def admin(request):
#  print(request.user.is_superuser)
  if request.headers['User-Agent']=='':
    return render(request,'404.html')
  if request.user.is_superuser==True:
    user=Info.objects.all()
    set1 = sett.ControlUser
    seting = set1.objects.get(id="1")
    balance=json.loads(requests.post('https://faucetpay.io/api/v1/getbalance',data={"api_key":{seting.api_key},"currency":seting.jenis_faucet}).text)
    if balance['status'] == 200:
      context={
        "balance":balance['balance_bitcoin'],
        "seting":seting,
        "sukses":"nothing",
        }
    else:
      context={
        "balance":"Please seting",
        "seting":seting,
        "sukses":"nothing",
        }
    if request.method=="POST":
      if 'api' in request.POST:
        seting.api_key = request.POST['api']
        seting.save()
        balance=json.loads(requests.post('https://faucetpay.io/api/v1/getbalance',data={"api_key":{seting.api_key},"currency":seting.jenis_faucet}).text)
        if balance['status'] == 200:
          context={
            "balance":balance['balance_bitcoin'],
            "seting":seting,
            "sukses":True,
            }
        return render(request,'admin_index.html',context)
      if 'name_web' in request.POST:
        seting.nama_faucet = request.POST['name_web']
        seting.save()
      if 'url' in request.POST:
        seting.url = request.POST['url']
        seting.save()
      if 'reward_wd' in request.POST:
        seting.reward_wd = request.POST['reward_wd']
        seting.save()
      if 'min_wd' in request.POST:
        seting.min_wd = request.POST['min_wd']
        seting.save()
      if 'logo' in request.POST:
        seting.logo = request.POST['logo']
        seting.save()
      if 'id' in request.POST:
        if request.POST['id'] == '1':
          seting.warna_faucet ='bg-gradient-primary'
          seting.save()
        if request.POST['id'] == '2':
          seting.warna_faucet ='bg-gradient-secondary'
          seting.save()
        if request.POST['id'] == '3':
          seting.warna_faucet ='bg-gradient-success'
          seting.save()
        if request.POST['id'] == '4':
          seting.warna_faucet ='bg-gradient-info'
          seting.save()
        if request.POST['id'] == '5':
          seting.warna_faucet ='bg-gradient-warning'
          seting.save()
        if request.POST['id'] == '6':
          seting.warna_faucet ='bg-gradient-danger'
          seting.save()
        if request.POST['id'] == '7':
          seting.warna_faucet ='bg-gradient-light'
          seting.save()
        if request.POST['id'] == '8':
          seting.warna_faucet ='bg-gradient-dark'
          seting.save()
      if 'name_coin' in request.POST:
        if request.POST['name_coin'] == '1':
          seting.jenis_faucet = 'BTC'
          seting.save()
        if request.POST['name_coin'] == '2':
          seting.jenis_faucet = 'ETH'
          seting.save()
        if request.POST['name_coin'] == '3':
          seting.jenis_faucet = 'DOGE'
          seting.save()
        if request.POST['name_coin'] == '4':
          seting.jenis_faucet = 'LTC'
          seting.save()
        if request.POST['name_coin'] == '5':
          seting.jenis_faucet = 'BCH'
          seting.save()
        if request.POST['name_coin'] == '6':
          seting.jenis_faucet = 'DASH'
          seting.save()
        if request.POST['name_coin'] == '7':
          seting.jenis_faucet = 'DGB'
          seting.save()
        if request.POST['name_coin'] == '8':
          seting.jenis_faucet = 'TRX'
          seting.save()
        if request.POST['name_coin'] == '9':
          seting.jenis_faucet = 'USDT'
          seting.save()
        if request.POST['name_coin'] == '10':
          seting.jenis_faucet = 'FEY'
          seting.save()
        if request.POST['name_coin'] == '11':
          seting.jenis_faucet = 'ZEC'
          seting.save()
        if request.POST['name_coin'] == '12':
          seting.jenis_faucet = 'BNB'
          seting.save()
        if request.POST['name_coin'] == '13':
          seting.jenis_faucet = 'SOL'
          seting.save()
        balance=json.loads(requests.post('https://faucetpay.io/api/v1/getbalance',data={"api_key":{seting.api_key},"currency":seting.jenis_faucet}).text)
        if balance['status'] == 200:
          context={
            "balance":balance['balance_bitcoin'],
            "seting":seting,
            "sukses":True,
            }
    return render(request,'admin_index.html',context)
  else:
    return redirect('/admin/login')
def admin_faucet(request):
  if request.headers['User-Agent']=='':
    return render(request,'404.html')
  if request.user.is_superuser==True:
    user=Info.objects.all()
    set1 = sett.ControlUser
    seting = set1.objects.get(id="1")
    balance=json.loads(requests.post('https://faucetpay.io/api/v1/getbalance',data={"api_key":{seting.api_key},"currency":seting.jenis_faucet}).text)
    if balance['status'] == 200:
      context={
        "balance":balance['balance_bitcoin'],
        "seting":seting,
        "sukses":"nothing",
        }
    else:
      context={
        "balance":"Please seting",
        "seting":seting,
        "sukses":"nothing",
        }
    if request.method=="POST":
       if 'reward_fc' in request.POST:
         seting.reward_claim = request.POST['reward_fc']
         seting.save()
       if 'long_claim' in request.POST:
         seting.lama_claim = request.POST['long_claim']
         seting.save()
       if 'claim_lm' in request.POST:
         seting.limit_faucet = request.POST['claim_lm']
         seting.save()
       
    return render(request,'admin_faucet.html',context)
  else:
    return redirect('/admin/login')
def admin_auto(request):
  if request.headers['User-Agent']=='':
    return render(request,'404.html')
  if request.user.is_superuser==True:
    user=Info.objects.all()
    set1 = sett.ControlUser
    seting = set1.objects.get(id="1")
    balance=json.loads(requests.post('https://faucetpay.io/api/v1/getbalance',data={"api_key":{seting.api_key},"currency":seting.jenis_faucet}).text)
    if balance['status'] == 200:
      context={
        "balance":balance['balance_bitcoin'],
        "seting":seting,
        "sukses":"nothing",
        }
    else:
      context={
        "balance":"Please seting",
        "seting":seting,
        "sukses":"nothing",
        }
    if request.method=="POST":
       if 'reward_fc' in request.POST:
         seting.reward_claim = request.POST['reward_fc']
         seting.save()
       if 'long_claim' in request.POST:
         seting.lama_claim = request.POST['long_claim']
         seting.save()
       if 'claim_lm' in request.POST:
         seting.limit_faucet = request.POST['claim_lm']
         seting.save()
       
    return render(request,'admin_auto.html',context)
  else:
    return redirect('/admin/login')
def admin_user_setting(request):
  if request.headers['User-Agent']=='':
    return render(request,'404.html')
  if request.user.is_superuser==True:
    user=Info.objects.all()
    set1 = sett.ControlUser
    seting = set1.objects.get(id="1")
    context={
      "username":user,
      "seting":seting,
      }
    if request.method=="POST":
      if 'banned' in request.POST:
        id=request.POST['banned']
        user_banned = Info.objects.get(id=id)
        user_banned.status='banned'
        user_banned.save()
      if 'update' in request.POST:
        id=request.POST['update']
        user_update = Info.objects.get(id=id)
        user_update.status=request.POST['status']
        user_update.balance=request.POST['balance']
        user_update.energi=request.POST['energi']
        user_update.username=request.POST['username']
        user_update.email=request.POST['email']
        user_update.join=request.POST['joined']
        user_update.ip=request.POST['ip']
        user_update.negara=request.POST['negara']
        user_update.save()
      if 'unbanned' in request.POST:
        id=request.POST['unbanned']
        user_banned = Info.objects.get(id=id)
        user_banned.status='active'
        user_banned.save()
    return render(request,'tables_list.html',context)
  else:
    return redirect('/admin/login')
def admin_user_list(request):
  if request.headers['User-Agent']=='':
    return render(request,'404.html')
  if str(request.user) == 'AnonymousUser':
    return redirect('/admin/login')
  if request.user.is_superuser==True:
    user=Info.objects.all()
    set1 = sett.ControlUser
    seting = set1.objects.get(id="1")
    context={
      "username":user,
      "seting":seting,
      }
    return render(request,'admin_user_list_tables.html',context)
def admin_login(request):
  if request.headers['User-Agent']=='':
    return render(request,'404.html')
  if request.user.is_superuser==True:
    return redirect('/admin')
  if request.method=='POST':
    user = authenticate(username=request.POST['username'], password=request.POST['password'])
    auth_login(request, user)
    if request.user.is_superuser==True:
      return redirect('/admin')
  set1 = sett.ControlUser
  seting = set1.objects.get(id="1")
  return render(request,'login_admin.html',context={"seting":seting})